email = ilham@gmail.com
password = ilham123

informasi akun terdapat di dalam file user.py